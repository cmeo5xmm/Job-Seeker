<h1>Registration<br>New Employer to Job-Hunt System? Register Below.</h1><p>
<form action="EmployerSignUp2.php"method="POST">
<b>Account:<input type="text" name="account">&nbsp;&nbsp;&nbsp;
Password:<input type="password" name="password"><br>
Phone Number:<input type="text" name="phonenumber">&nbsp;&nbsp;&nbsp;
Email:<input type="text" name="email"><br></b>
<button type="submit"><span style="font-family:fantasy;">Submit</span></button>
</form>